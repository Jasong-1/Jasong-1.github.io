newFunction();

function newFunction() {
    $("#solution_nav").on("click", function () { $("html,body").animate({ scrollTop: $("#solution").offset().top }, 1000); });
}
